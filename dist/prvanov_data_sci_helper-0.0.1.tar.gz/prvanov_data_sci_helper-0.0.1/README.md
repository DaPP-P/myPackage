# myPackage

Some basics functions that I find useful.